"use client"

import { useState } from "react"
import { UserPlus, Trash2, Building2, Download, RotateCcw } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import { ALL_ROLES, ALL_SKILLS, type Role, type Skill } from "@/lib/types"
import { buildScheduleCsv, downloadCsv } from "@/lib/export"
import { Badge, Card, CardBody, CardHeader, Field, Input, PageHeader, Select } from "@/components/ui-kit"
import { Button } from "@/components/ui/button"

export default function AdminPage() {
  const { nurses, wards, assignments, addNurse, removeNurse, addWard, removeWard, resetData } = useScheduling()

  // nurse form
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [role, setRole] = useState<Role>("Registered Nurse")
  const [maxHours, setMaxHours] = useState(40)
  const [nurseSkills, setNurseSkills] = useState<Skill[]>([])

  // ward form
  const [wardName, setWardName] = useState("")
  const [minStaff, setMinStaff] = useState(2)
  const [wardSkills, setWardSkills] = useState<Skill[]>([])

  function toggle<T>(arr: T[], v: T): T[] {
    return arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]
  }

  function handleAddNurse() {
    if (!name.trim()) return
    addNurse({
      name: name.trim(),
      email: email.trim() || `${name.toLowerCase().replace(/\s+/g, ".")}@hospital.org`,
      phone: phone.trim() || "+1 (555) 000-0000",
      role,
      skills: nurseSkills,
      preferredWardId: null,
      maxHoursPerWeek: Number(maxHours),
      active: true,
    })
    setName("")
    setEmail("")
    setPhone("")
    setNurseSkills([])
  }

  function handleAddWard() {
    if (!wardName.trim()) return
    addWard({ name: wardName.trim(), requiredSkills: wardSkills, minStaffPerShift: Number(minStaff) })
    setWardName("")
    setWardSkills([])
  }

  return (
    <>
      <PageHeader
        title="Admin Panel"
        description="Manage staff, wards, and system data."
        action={
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="gap-2"
              onClick={() => downloadCsv("full-schedule.csv", buildScheduleCsv(assignments, nurses, wards))}
            >
              <Download className="size-4" /> Export All
            </Button>
            <Button variant="destructive" className="gap-2" onClick={resetData}>
              <RotateCcw className="size-4" /> Reset Demo
            </Button>
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Add nurse */}
        <Card>
          <CardHeader title="Add Nurse" />
          <CardBody className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Full Name">
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" />
              </Field>
              <Field label="Role">
                <Select value={role} onChange={(e) => setRole(e.target.value as Role)}>
                  {ALL_ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Email">
                <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@hospital.org" />
              </Field>
              <Field label="Phone">
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+1 (555) 000-0000" />
              </Field>
            </div>
            <Field label="Max Hours / Week">
              <Input type="number" min={0} max={80} value={maxHours} onChange={(e) => setMaxHours(Number(e.target.value))} />
            </Field>
            <div>
              <p className="mb-2 text-sm font-medium">Skills</p>
              <div className="flex flex-wrap gap-2">
                {ALL_SKILLS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setNurseSkills((p) => toggle(p, s))}
                    className={`rounded-full px-3 py-1 text-xs font-medium transition ${
                      nurseSkills.includes(s) ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-accent"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <Button onClick={handleAddNurse} className="gap-2">
              <UserPlus className="size-4" /> Add Nurse
            </Button>
          </CardBody>
        </Card>

        {/* Add ward */}
        <Card>
          <CardHeader title="Add Ward" />
          <CardBody className="space-y-4">
            <Field label="Ward Name">
              <Input value={wardName} onChange={(e) => setWardName(e.target.value)} placeholder="Neurology Ward" />
            </Field>
            <Field label="Min Staff / Shift">
              <Input type="number" min={1} max={20} value={minStaff} onChange={(e) => setMinStaff(Number(e.target.value))} />
            </Field>
            <div>
              <p className="mb-2 text-sm font-medium">Required Skills</p>
              <div className="flex flex-wrap gap-2">
                {ALL_SKILLS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setWardSkills((p) => toggle(p, s))}
                    className={`rounded-full px-3 py-1 text-xs font-medium transition ${
                      wardSkills.includes(s) ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-accent"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <Button onClick={handleAddWard} className="gap-2">
              <Building2 className="size-4" /> Add Ward
            </Button>
          </CardBody>
        </Card>
      </div>

      {/* Staff list */}
      <Card>
        <CardHeader title="Staff Directory" description={`${nurses.length} nurses on the roster.`} />
        <CardBody>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-muted-foreground">
                  <th className="py-2 pr-4 font-medium">Name</th>
                  <th className="py-2 pr-4 font-medium">Role</th>
                  <th className="py-2 pr-4 font-medium">Skills</th>
                  <th className="py-2 pr-4 font-medium">Max h/wk</th>
                  <th className="py-2 font-medium" />
                </tr>
              </thead>
              <tbody>
                {nurses.map((n) => (
                  <tr key={n.id} className="border-b border-border/60">
                    <td className="py-2 pr-4 font-medium">{n.name}</td>
                    <td className="py-2 pr-4">{n.role}</td>
                    <td className="py-2 pr-4">
                      <div className="flex flex-wrap gap-1">
                        {n.skills.map((s) => (
                          <Badge key={s}>{s}</Badge>
                        ))}
                      </div>
                    </td>
                    <td className="py-2 pr-4">{n.maxHoursPerWeek}</td>
                    <td className="py-2 text-right">
                      <button
                        type="button"
                        onClick={() => removeNurse(n.id)}
                        className="rounded p-1 text-muted-foreground hover:bg-red-100 hover:text-red-600"
                        aria-label="Remove nurse"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Ward list */}
      <Card>
        <CardHeader title="Wards" description={`${wards.length} wards configured.`} />
        <CardBody className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {wards.map((w) => (
            <div key={w.id} className="rounded-lg border border-border p-4">
              <div className="flex items-start justify-between">
                <p className="font-medium">{w.name}</p>
                <button
                  type="button"
                  onClick={() => removeWard(w.id)}
                  className="rounded p-1 text-muted-foreground hover:bg-red-100 hover:text-red-600"
                  aria-label="Remove ward"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">Min {w.minStaffPerShift} staff / shift</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {w.requiredSkills.map((s) => (
                  <Badge key={s}>{s}</Badge>
                ))}
              </div>
            </div>
          ))}
        </CardBody>
      </Card>
    </>
  )
}
