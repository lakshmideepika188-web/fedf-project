"use client"

import { TriangleAlert, CalendarX, PlaneTakeoff, ShieldX, Timer, Trash2 } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import type { ConflictType } from "@/lib/types"
import { Badge, Card, CardBody, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui-kit"
import { Button } from "@/components/ui/button"

const META: Record<ConflictType, { icon: typeof TriangleAlert; tone: "danger" | "warning" }> = {
  "Double Booking": { icon: CalendarX, tone: "danger" },
  "On Leave": { icon: PlaneTakeoff, tone: "danger" },
  "Skill Mismatch": { icon: ShieldX, tone: "warning" },
  Overtime: { icon: Timer, tone: "warning" },
}

export default function ConflictsPage() {
  const { conflicts, nurses, removeAssignment } = useScheduling()

  const counts = conflicts.reduce<Record<string, number>>((acc, c) => {
    acc[c.type] = (acc[c.type] ?? 0) + 1
    return acc
  }, {})

  return (
    <>
      <PageHeader
        title="Conflict Alerts"
        description="Automatically detected scheduling issues across the roster."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Double Bookings" value={counts["Double Booking"] ?? 0} tone="danger" icon={<CalendarX className="size-5" />} />
        <StatCard label="Leave Clashes" value={counts["On Leave"] ?? 0} tone="danger" icon={<PlaneTakeoff className="size-5" />} />
        <StatCard label="Skill Mismatch" value={counts["Skill Mismatch"] ?? 0} tone="warning" icon={<ShieldX className="size-5" />} />
        <StatCard label="Overtime" value={counts["Overtime"] ?? 0} tone="warning" icon={<Timer className="size-5" />} />
      </div>

      <Card>
        <CardHeader title="All Conflicts" description={`${conflicts.length} issues need attention.`} />
        <CardBody className="space-y-3">
          {conflicts.length === 0 ? (
            <EmptyState message="No conflicts detected. The schedule is clean." />
          ) : (
            conflicts.map((c) => {
              const Meta = META[c.type]
              const Icon = Meta.icon
              const nurse = nurses.find((n) => n.id === c.nurseId)
              return (
                <div key={c.id} className="flex items-start justify-between gap-4 rounded-lg border border-border p-4">
                  <div className="flex gap-3">
                    <span
                      className={
                        Meta.tone === "danger"
                          ? "mt-0.5 text-red-600"
                          : "mt-0.5 text-amber-600"
                      }
                    >
                      <Icon className="size-5" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <Badge tone={Meta.tone}>{c.type}</Badge>
                        <span className="text-sm font-medium">{nurse?.name}</span>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">{c.message}</p>
                    </div>
                  </div>
                  {(c.type === "Double Booking" || c.type === "On Leave" || c.type === "Skill Mismatch") &&
                  c.assignmentIds.length > 0 ? (
                    <Button
                      variant="destructive"
                      size="sm"
                      className="gap-1.5"
                      onClick={() => c.assignmentIds.forEach((id) => removeAssignment(id))}
                    >
                      <Trash2 className="size-3.5" /> Resolve
                    </Button>
                  ) : null}
                </div>
              )
            })
          )}
        </CardBody>
      </Card>
    </>
  )
}
