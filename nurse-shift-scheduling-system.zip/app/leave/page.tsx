"use client"

import { useState } from "react"
import { Check, X, Trash2, Send } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import { ALL_LEAVE_TYPES, type LeaveType } from "@/lib/types"
import { Badge, Card, CardBody, CardHeader, EmptyState, Field, Input, PageHeader, Select, Textarea } from "@/components/ui-kit"
import { Button } from "@/components/ui/button"

export default function LeavePage() {
  const { nurses, leave, addLeave, setLeaveStatus, removeLeave } = useScheduling()
  const today = new Date().toISOString().slice(0, 10)

  const [nurseId, setNurseId] = useState(nurses[0]?.id ?? "")
  const [type, setType] = useState<LeaveType>("Annual")
  const [startDate, setStartDate] = useState(today)
  const [endDate, setEndDate] = useState(today)
  const [reason, setReason] = useState("")

  function handleSubmit() {
    if (!nurseId || endDate < startDate) return
    addLeave({ nurseId, type, startDate, endDate, reason })
    setReason("")
  }

  const sorted = [...leave].sort((a, b) => b.createdAt.localeCompare(a.createdAt))

  return (
    <>
      <PageHeader title="Leave Requests" description="Submit and review nurse leave applications." />

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <CardHeader title="Request Leave" />
          <CardBody className="space-y-4">
            <Field label="Nurse">
              <Select value={nurseId} onChange={(e) => setNurseId(e.target.value)}>
                {nurses.map((n) => (
                  <option key={n.id} value={n.id}>
                    {n.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Leave Type">
              <Select value={type} onChange={(e) => setType(e.target.value as LeaveType)}>
                {ALL_LEAVE_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </Select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="From">
                <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
              </Field>
              <Field label="To">
                <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
              </Field>
            </div>
            <Field label="Reason">
              <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Brief reason for the request" />
            </Field>
            <Button onClick={handleSubmit} className="w-full gap-2">
              <Send className="size-4" /> Submit Request
            </Button>
          </CardBody>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader title="Requests" description={`${leave.filter((l) => l.status === "Pending").length} pending review.`} />
          <CardBody className="space-y-3">
            {sorted.length === 0 ? (
              <EmptyState message="No leave requests yet." />
            ) : (
              sorted.map((l) => {
                const nurse = nurses.find((n) => n.id === l.nurseId)
                const tone = l.status === "Approved" ? "success" : l.status === "Rejected" ? "danger" : "warning"
                return (
                  <div key={l.id} className="rounded-lg border border-border p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-medium">{nurse?.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {l.type} · {l.startDate} → {l.endDate}
                        </p>
                        {l.reason ? <p className="mt-1 text-sm text-muted-foreground">{l.reason}</p> : null}
                      </div>
                      <Badge tone={tone}>{l.status}</Badge>
                    </div>
                    <div className="mt-3 flex gap-2">
                      {l.status !== "Approved" ? (
                        <Button size="sm" className="gap-1.5" onClick={() => setLeaveStatus(l.id, "Approved")}>
                          <Check className="size-3.5" /> Approve
                        </Button>
                      ) : null}
                      {l.status !== "Rejected" ? (
                        <Button size="sm" variant="destructive" className="gap-1.5" onClick={() => setLeaveStatus(l.id, "Rejected")}>
                          <X className="size-3.5" /> Reject
                        </Button>
                      ) : null}
                      <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => removeLeave(l.id)}>
                        <Trash2 className="size-3.5" /> Delete
                      </Button>
                    </div>
                  </div>
                )
              })
            )}
          </CardBody>
        </Card>
      </div>
    </>
  )
}
