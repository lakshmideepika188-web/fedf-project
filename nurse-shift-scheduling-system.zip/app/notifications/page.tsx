"use client"

import { Bell, CheckCheck, Trash2, Info, TriangleAlert, CircleCheck, CircleAlert } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import type { AppNotification } from "@/lib/types"
import { Card, CardBody, CardHeader, EmptyState, PageHeader } from "@/components/ui-kit"
import { Button } from "@/components/ui/button"

const LEVEL: Record<AppNotification["level"], { icon: typeof Info; className: string }> = {
  info: { icon: Info, className: "text-primary" },
  warning: { icon: TriangleAlert, className: "text-amber-600" },
  danger: { icon: CircleAlert, className: "text-red-600" },
  success: { icon: CircleCheck, className: "text-emerald-600" },
}

export default function NotificationsPage() {
  const { notifications, markNotificationRead, markAllNotificationsRead, clearNotifications } = useScheduling()
  const unread = notifications.filter((n) => !n.read).length

  return (
    <>
      <PageHeader
        title="Notifications"
        description={`${unread} unread of ${notifications.length} total.`}
        action={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={markAllNotificationsRead}>
              <CheckCheck className="size-4" /> Mark all read
            </Button>
            <Button variant="ghost" size="sm" className="gap-1.5" onClick={clearNotifications}>
              <Trash2 className="size-4" /> Clear
            </Button>
          </div>
        }
      />

      <Card>
        <CardHeader title="Activity Feed" />
        <CardBody className="space-y-2">
          {notifications.length === 0 ? (
            <EmptyState message="You're all caught up." />
          ) : (
            notifications.map((n) => {
              const Meta = LEVEL[n.level]
              const Icon = Meta.icon
              return (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => markNotificationRead(n.id)}
                  className={`flex w-full items-start gap-3 rounded-lg border p-3 text-left transition ${
                    n.read ? "border-border bg-card" : "border-primary/30 bg-accent/40"
                  }`}
                >
                  <span className={Meta.className}>
                    <Icon className="size-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium">{n.title}</p>
                      {!n.read ? <span className="size-2 shrink-0 rounded-full bg-primary" /> : null}
                    </div>
                    <p className="text-sm text-muted-foreground">{n.message}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {new Date(n.createdAt).toLocaleString()}
                    </p>
                  </div>
                </button>
              )
            })
          )}
        </CardBody>
      </Card>

      {notifications.length === 0 ? (
        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Bell className="size-4" /> New alerts will appear here as you manage schedules.
        </div>
      ) : null}
    </>
  )
}
