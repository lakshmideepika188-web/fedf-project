"use client"

import { useMemo } from "react"
import { Timer } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import { Badge, Card, CardBody, CardHeader, PageHeader, StatCard } from "@/components/ui-kit"

export default function OvertimePage() {
  const { nurses, assignments, weeklyHours } = useScheduling()

  const rows = useMemo(() => {
    return nurses
      .map((n) => {
        const hours = weeklyHours(n.id)
        const pct = Math.min(100, Math.round((hours / n.maxHoursPerWeek) * 100))
        const over = hours > n.maxHoursPerWeek
        return { nurse: n, hours, pct, over, overBy: Math.max(0, hours - n.maxHoursPerWeek) }
      })
      .sort((a, b) => b.pct - a.pct)
  }, [nurses, weeklyHours, assignments])

  const overCount = rows.filter((r) => r.over).length
  const totalHours = rows.reduce((sum, r) => sum + r.hours, 0)

  return (
    <>
      <PageHeader title="Overtime Tracker" description="Monitor weekly scheduled hours against each nurse's limit." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">
        <StatCard label="Nurses in Overtime" value={overCount} tone={overCount ? "danger" : "success"} icon={<Timer className="size-5" />} />
        <StatCard label="Total Scheduled Hours" value={`${totalHours}h`} hint="Peak week per nurse" />
        <StatCard label="Avg Utilization" value={`${rows.length ? Math.round(rows.reduce((s, r) => s + r.pct, 0) / rows.length) : 0}%`} tone="primary" />
      </div>

      <Card>
        <CardHeader title="Weekly Hours" description="Bars show utilization vs. each nurse's maximum weekly hours." />
        <CardBody className="space-y-4">
          {rows.map(({ nurse, hours, pct, over, overBy }) => (
            <div key={nurse.id}>
              <div className="mb-1.5 flex items-center justify-between text-sm">
                <span className="font-medium">{nurse.name}</span>
                <span className="flex items-center gap-2 text-muted-foreground">
                  {hours}h / {nurse.maxHoursPerWeek}h
                  {over ? <Badge tone="danger">+{overBy}h over</Badge> : null}
                </span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded-full bg-secondary">
                <div
                  className={over ? "h-full rounded-full bg-red-500" : pct > 85 ? "h-full rounded-full bg-amber-500" : "h-full rounded-full bg-primary"}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          ))}
        </CardBody>
      </Card>
    </>
  )
}
