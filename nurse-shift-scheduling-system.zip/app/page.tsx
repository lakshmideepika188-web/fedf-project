"use client"

import Link from "next/link"
import { Users, CalendarCheck, TriangleAlert, PlaneTakeoff, ArrowRight } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import { SHIFT_DEFS, ALL_SHIFTS } from "@/lib/types"
import { Badge, Card, CardBody, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui-kit"

export default function DashboardPage() {
  const { nurses, wards, assignments, leave, conflicts } = useScheduling()
  const today = new Date().toISOString().slice(0, 10)
  const todays = assignments.filter((a) => a.date === today)
  const pendingLeave = leave.filter((l) => l.status === "Pending")
  const activeNurses = nurses.filter((n) => n.active)

  return (
    <>
      <PageHeader
        title="Dashboard"
        description="Overview of staffing, coverage, and alerts across all wards."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Active Nurses" value={activeNurses.length} hint={`${nurses.length} total on roster`} icon={<Users className="size-5" />} />
        <StatCard label="Shifts Today" value={todays.length} hint={`${assignments.length} scheduled total`} tone="success" icon={<CalendarCheck className="size-5" />} />
        <StatCard label="Open Conflicts" value={conflicts.length} hint="Needs review" tone={conflicts.length ? "danger" : "success"} icon={<TriangleAlert className="size-5" />} />
        <StatCard label="Pending Leave" value={pendingLeave.length} hint="Awaiting approval" tone="warning" icon={<PlaneTakeoff className="size-5" />} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title="Today's Coverage"
            description="Nurses assigned across shifts for the current day."
            action={
              <Link href="/roster" className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline">
                Roster <ArrowRight className="size-4" />
              </Link>
            }
          />
          <CardBody className="space-y-4">
            {ALL_SHIFTS.map((shift) => {
              const list = todays.filter((a) => a.shift === shift)
              return (
                <div key={shift}>
                  <div className="mb-2 flex items-center justify-between">
                    <p className="text-sm font-medium">{SHIFT_DEFS[shift].label}</p>
                    <Badge tone={list.length ? "primary" : "neutral"}>{list.length} assigned</Badge>
                  </div>
                  {list.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No nurses assigned.</p>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {list.map((a) => {
                        const nurse = nurses.find((n) => n.id === a.nurseId)
                        const ward = wards.find((w) => w.id === a.wardId)
                        return (
                          <span key={a.id} className="rounded-md border border-border bg-secondary px-2.5 py-1 text-xs">
                            <span className="font-medium">{nurse?.name}</span>
                            <span className="text-muted-foreground"> · {ward?.name}</span>
                          </span>
                        )
                      })}
                    </div>
                  )}
                </div>
              )
            })}
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Recent Alerts"
            action={
              <Link href="/conflicts" className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline">
                All <ArrowRight className="size-4" />
              </Link>
            }
          />
          <CardBody className="space-y-3">
            {conflicts.length === 0 ? (
              <EmptyState message="No conflicts detected. Schedule looks healthy." />
            ) : (
              conflicts.slice(0, 5).map((c) => (
                <div key={c.id} className="rounded-md border border-border p-3">
                  <Badge tone="danger">{c.type}</Badge>
                  <p className="mt-1.5 text-sm text-muted-foreground">{c.message}</p>
                </div>
              ))
            )}
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader title="Wards" description="Departments and their required skill sets." />
        <CardBody className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {wards.map((w) => (
            <div key={w.id} className="rounded-lg border border-border p-4">
              <p className="font-medium">{w.name}</p>
              <p className="mt-1 text-xs text-muted-foreground">Min {w.minStaffPerShift} staff / shift</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {w.requiredSkills.map((s) => (
                  <Badge key={s}>{s}</Badge>
                ))}
              </div>
            </div>
          ))}
        </CardBody>
      </Card>
    </>
  )
}
