"use client"

import { useEffect, useState } from "react"
import { Mail, Phone, Building2, Clock, Save } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import { ALL_SKILLS, type Skill } from "@/lib/types"
import { Badge, Card, CardBody, CardHeader, EmptyState, Field, Input, PageHeader, Select, StatCard } from "@/components/ui-kit"
import { Button } from "@/components/ui/button"

export default function ProfilePage() {
  const { nurses, wards, assignments, leave, weeklyHours, updateNurse } = useScheduling()
  const [selectedId, setSelectedId] = useState(nurses[0]?.id ?? "")

  const nurse = nurses.find((n) => n.id === selectedId)
  const [phone, setPhone] = useState(nurse?.phone ?? "")
  const [maxHours, setMaxHours] = useState(nurse?.maxHoursPerWeek ?? 40)
  const [skills, setSkills] = useState<Skill[]>(nurse?.skills ?? [])

  // sync local form when the selected nurse changes
  useEffect(() => {
    if (nurse) {
      setPhone(nurse.phone)
      setMaxHours(nurse.maxHoursPerWeek)
      setSkills(nurse.skills)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId])

  if (!nurse) return <EmptyState message="No nurse selected." />

  const myAssignments = assignments
    .filter((a) => a.nurseId === nurse.id)
    .sort((a, b) => b.date.localeCompare(a.date))
  const myLeave = leave.filter((l) => l.nurseId === nurse.id)
  const hours = weeklyHours(nurse.id)
  const prefWard = wards.find((w) => w.id === nurse.preferredWardId)

  function toggleSkill(s: Skill) {
    setSkills((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]))
  }

  function save() {
    updateNurse(nurse!.id, { phone, maxHoursPerWeek: Number(maxHours), skills })
  }

  return (
    <>
      <PageHeader
        title="Profile"
        description="View and update a nurse's details, skills, and schedule."
        action={
          <Select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="min-w-48">
            {nurses.map((n) => (
              <option key={n.id} value={n.id}>
                {n.name}
              </option>
            ))}
          </Select>
        }
      />

      <Card>
        <CardBody className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="flex size-16 items-center justify-center rounded-full bg-primary text-2xl font-semibold text-primary-foreground">
            {nurse.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}
          </div>
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-xl font-semibold">{nurse.name}</h2>
              <Badge tone={nurse.active ? "success" : "neutral"}>{nurse.active ? "Active" : "Inactive"}</Badge>
            </div>
            <p className="text-sm text-muted-foreground">{nurse.role}</p>
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5"><Mail className="size-4" /> {nurse.email}</span>
              <span className="flex items-center gap-1.5"><Phone className="size-4" /> {nurse.phone}</span>
              <span className="flex items-center gap-1.5"><Building2 className="size-4" /> {prefWard?.name ?? "No preference"}</span>
            </div>
          </div>
        </CardBody>
      </Card>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Weekly Hours" value={`${hours}h`} hint={`Limit ${nurse.maxHoursPerWeek}h`} tone={hours > nurse.maxHoursPerWeek ? "danger" : "primary"} icon={<Clock className="size-5" />} />
        <StatCard label="Upcoming Shifts" value={myAssignments.length} tone="success" />
        <StatCard label="Skills" value={nurse.skills.length} />
        <StatCard label="Leave Requests" value={myLeave.length} tone="warning" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Edit Details" />
          <CardBody className="space-y-4">
            <Field label="Phone">
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
            </Field>
            <Field label="Max Hours / Week">
              <Input type="number" min={0} max={80} value={maxHours} onChange={(e) => setMaxHours(Number(e.target.value))} />
            </Field>
            <div>
              <p className="mb-2 text-sm font-medium">Skills</p>
              <div className="flex flex-wrap gap-2">
                {ALL_SKILLS.map((s) => {
                  const on = skills.includes(s)
                  return (
                    <button
                      key={s}
                      type="button"
                      onClick={() => toggleSkill(s)}
                      className={`rounded-full px-3 py-1 text-xs font-medium transition ${
                        on ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-accent"
                      }`}
                    >
                      {s}
                    </button>
                  )
                })}
              </div>
            </div>
            <Button onClick={save} className="gap-2">
              <Save className="size-4" /> Save Changes
            </Button>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Upcoming Shifts" />
          <CardBody className="space-y-2">
            {myAssignments.length === 0 ? (
              <EmptyState message="No shifts assigned." />
            ) : (
              myAssignments.map((a) => {
                const ward = wards.find((w) => w.id === a.wardId)
                return (
                  <div key={a.id} className="flex items-center justify-between rounded-md border border-border p-2.5 text-sm">
                    <span>
                      <span className="font-medium">{a.date}</span>
                      <span className="text-muted-foreground"> · {a.shift}</span>
                    </span>
                    <span className="text-muted-foreground">{ward?.name}</span>
                  </div>
                )
              })
            )}
          </CardBody>
        </Card>
      </div>
    </>
  )
}
