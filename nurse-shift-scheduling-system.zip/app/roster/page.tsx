"use client"

import { useMemo, useState } from "react"
import { Download, Trash2 } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import { ALL_SHIFTS, SHIFT_DEFS } from "@/lib/types"
import { buildScheduleCsv, downloadCsv } from "@/lib/export"
import { Badge, Card, CardBody, CardHeader, Input, PageHeader, Select } from "@/components/ui-kit"
import { Button } from "@/components/ui/button"

export default function RosterPage() {
  const { nurses, wards, assignments, conflicts, removeAssignment } = useScheduling()
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [wardFilter, setWardFilter] = useState("all")

  const dayAssignments = useMemo(
    () =>
      assignments.filter(
        (a) => a.date === date && (wardFilter === "all" || a.wardId === wardFilter),
      ),
    [assignments, date, wardFilter],
  )

  const conflictAssignmentIds = useMemo(
    () => new Set(conflicts.flatMap((c) => c.assignmentIds)),
    [conflicts],
  )

  const visibleWards = wards.filter((w) => wardFilter === "all" || w.id === wardFilter)

  return (
    <>
      <PageHeader
        title="Roster Builder"
        description="Visualize and manage the daily roster grouped by ward and shift."
        action={
          <Button
            onClick={() => downloadCsv(`roster-${date}.csv`, buildScheduleCsv(dayAssignments, nurses, wards))}
            className="gap-2"
          >
            <Download className="size-4" /> Export Day
          </Button>
        }
      />

      <Card>
        <CardBody className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <label className="flex flex-1 flex-col gap-1.5 text-sm">
            <span className="font-medium">Date</span>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </label>
          <label className="flex flex-1 flex-col gap-1.5 text-sm">
            <span className="font-medium">Ward</span>
            <Select value={wardFilter} onChange={(e) => setWardFilter(e.target.value)}>
              <option value="all">All wards</option>
              {wards.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </Select>
          </label>
        </CardBody>
      </Card>

      <div className="space-y-4">
        {visibleWards.map((ward) => {
          const wardAssignments = dayAssignments.filter((a) => a.wardId === ward.id)
          return (
            <Card key={ward.id}>
              <CardHeader
                title={ward.name}
                description={`Requires: ${ward.requiredSkills.join(", ") || "none"} · Min ${ward.minStaffPerShift}/shift`}
              />
              <CardBody className="grid gap-4 md:grid-cols-3">
                {ALL_SHIFTS.map((shift) => {
                  const list = wardAssignments.filter((a) => a.shift === shift)
                  const understaffed = list.length < ward.minStaffPerShift
                  return (
                    <div key={shift} className="rounded-lg border border-border p-3">
                      <div className="mb-2 flex items-center justify-between">
                        <p className="text-sm font-medium">{shift}</p>
                        <Badge tone={understaffed ? "warning" : "success"}>
                          {list.length}/{ward.minStaffPerShift}
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        {list.length === 0 ? (
                          <p className="text-xs text-muted-foreground">Unstaffed</p>
                        ) : (
                          list.map((a) => {
                            const nurse = nurses.find((n) => n.id === a.nurseId)
                            const hasConflict = conflictAssignmentIds.has(a.id)
                            return (
                              <div
                                key={a.id}
                                className="flex items-center justify-between rounded-md border border-border bg-secondary px-2.5 py-1.5"
                              >
                                <div className="min-w-0">
                                  <p className="truncate text-xs font-medium">{nurse?.name}</p>
                                  <p className="text-[11px] text-muted-foreground">{nurse?.role}</p>
                                </div>
                                <div className="flex items-center gap-1">
                                  {hasConflict ? <Badge tone="danger">!</Badge> : null}
                                  <button
                                    type="button"
                                    onClick={() => removeAssignment(a.id)}
                                    className="rounded p-1 text-muted-foreground hover:bg-red-100 hover:text-red-600"
                                    aria-label="Remove assignment"
                                  >
                                    <Trash2 className="size-3.5" />
                                  </button>
                                </div>
                              </div>
                            )
                          })
                        )}
                      </div>
                    </div>
                  )
                })}
              </CardBody>
            </Card>
          )
        })}
      </div>
    </>
  )
}
