"use client"

import { useMemo, useState } from "react"
import { CalendarPlus, CheckCircle2, AlertCircle, Trash2 } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import { ALL_SHIFTS, SHIFT_DEFS, type ShiftType } from "@/lib/types"
import { Badge, Card, CardBody, CardHeader, EmptyState, Field, Input, PageHeader, Select } from "@/components/ui-kit"
import { Button } from "@/components/ui/button"

export default function ShiftsPage() {
  const { nurses, wards, assignments, leave, addAssignment, removeAssignment } = useScheduling()

  const [wardId, setWardId] = useState(wards[0]?.id ?? "")
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [shift, setShift] = useState<ShiftType>("Morning")
  const [nurseId, setNurseId] = useState("")

  const ward = wards.find((w) => w.id === wardId)

  // Rank nurses: those with matching skills first, exclude inactive
  const rankedNurses = useMemo(() => {
    return nurses
      .filter((n) => n.active)
      .map((n) => {
        const matches = ward ? ward.requiredSkills.filter((s) => n.skills.includes(s)).length : 0
        const onLeave = leave.some(
          (l) => l.nurseId === n.id && l.status === "Approved" && date >= l.startDate && date <= l.endDate,
        )
        const alreadyToday = assignments.some((a) => a.nurseId === n.id && a.date === date)
        return { nurse: n, matches, onLeave, alreadyToday }
      })
      .sort((a, b) => b.matches - a.matches)
  }, [nurses, ward, leave, date, assignments])

  function handleAssign() {
    if (!nurseId || !wardId) return
    addAssignment({ nurseId, wardId, date, shift })
    setNurseId("")
  }

  const filtered = [...assignments].sort((a, b) =>
    a.date === b.date ? a.shift.localeCompare(b.shift) : b.date.localeCompare(a.date),
  )

  return (
    <>
      <PageHeader title="Shift Assignment" description="Assign nurses to ward shifts with built-in skill guidance." />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="New Assignment" />
          <CardBody className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Ward">
                <Select value={wardId} onChange={(e) => setWardId(e.target.value)}>
                  {wards.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Shift">
                <Select value={shift} onChange={(e) => setShift(e.target.value as ShiftType)}>
                  {ALL_SHIFTS.map((s) => (
                    <option key={s} value={s}>
                      {SHIFT_DEFS[s].label}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            <Field label="Date">
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
            <Field label="Nurse (sorted by skill match)">
              <Select value={nurseId} onChange={(e) => setNurseId(e.target.value)}>
                <option value="">Select a nurse…</option>
                {rankedNurses.map(({ nurse, matches, onLeave, alreadyToday }) => (
                  <option key={nurse.id} value={nurse.id}>
                    {nurse.name} — {matches > 0 ? `${matches} skill match` : "no match"}
                    {onLeave ? " · ON LEAVE" : ""}
                    {alreadyToday ? " · already scheduled" : ""}
                  </option>
                ))}
              </Select>
            </Field>

            {ward ? (
              <div className="rounded-md border border-border bg-secondary p-3 text-sm">
                <p className="font-medium">Required skills for {ward.name}</p>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {ward.requiredSkills.length ? (
                    ward.requiredSkills.map((s) => <Badge key={s}>{s}</Badge>)
                  ) : (
                    <span className="text-muted-foreground">No specific skills required.</span>
                  )}
                </div>
              </div>
            ) : null}

            <Button onClick={handleAssign} disabled={!nurseId} className="w-full gap-2">
              <CalendarPlus className="size-4" /> Assign Shift
            </Button>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Skill Suitability" description={`Candidates for ${ward?.name ?? "selected ward"} on ${date}.`} />
          <CardBody className="space-y-2">
            {rankedNurses.length === 0 ? (
              <EmptyState message="No active nurses available." />
            ) : (
              rankedNurses.slice(0, 8).map(({ nurse, matches, onLeave, alreadyToday }) => (
                <div key={nurse.id} className="flex items-center justify-between rounded-md border border-border p-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{nurse.name}</p>
                    <p className="text-xs text-muted-foreground">{nurse.role}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {onLeave ? <Badge tone="danger">On leave</Badge> : null}
                    {alreadyToday ? <Badge tone="warning">Scheduled</Badge> : null}
                    {matches > 0 ? (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600">
                        <CheckCircle2 className="size-4" /> {matches} match
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600">
                        <AlertCircle className="size-4" /> no match
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader title="All Assignments" description={`${assignments.length} scheduled shifts.`} />
        <CardBody>
          {filtered.length === 0 ? (
            <EmptyState message="No assignments yet." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-muted-foreground">
                    <th className="py-2 pr-4 font-medium">Date</th>
                    <th className="py-2 pr-4 font-medium">Shift</th>
                    <th className="py-2 pr-4 font-medium">Ward</th>
                    <th className="py-2 pr-4 font-medium">Nurse</th>
                    <th className="py-2 pr-4 font-medium">Hours</th>
                    <th className="py-2 font-medium" />
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((a) => {
                    const nurse = nurses.find((n) => n.id === a.nurseId)
                    const w = wards.find((x) => x.id === a.wardId)
                    return (
                      <tr key={a.id} className="border-b border-border/60">
                        <td className="py-2 pr-4">{a.date}</td>
                        <td className="py-2 pr-4">{a.shift}</td>
                        <td className="py-2 pr-4">{w?.name}</td>
                        <td className="py-2 pr-4">{nurse?.name}</td>
                        <td className="py-2 pr-4">{a.hours}h</td>
                        <td className="py-2 text-right">
                          <button
                            type="button"
                            onClick={() => removeAssignment(a.id)}
                            className="rounded p-1 text-muted-foreground hover:bg-red-100 hover:text-red-600"
                            aria-label="Remove"
                          >
                            <Trash2 className="size-4" />
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardBody>
      </Card>
    </>
  )
}
