"use client"

import { useMemo, useState } from "react"
import { Check, X } from "lucide-react"
import { useScheduling } from "@/lib/scheduling-context"
import { ALL_SKILLS } from "@/lib/types"
import { Badge, Card, CardBody, CardHeader, EmptyState, PageHeader, Select } from "@/components/ui-kit"

export default function SkillsPage() {
  const { nurses, wards } = useScheduling()
  const [wardId, setWardId] = useState("all")

  const matrix = useMemo(() => {
    return nurses.map((n) => ({
      nurse: n,
      skills: ALL_SKILLS.reduce<Record<string, boolean>>((acc, s) => {
        acc[s] = n.skills.includes(s)
        return acc
      }, {}),
    }))
  }, [nurses])

  const matches = useMemo(() => {
    if (wardId === "all") return null
    const ward = wards.find((w) => w.id === wardId)
    if (!ward) return null
    return nurses
      .map((n) => {
        const met = ward.requiredSkills.filter((s) => n.skills.includes(s))
        return { nurse: n, met, full: met.length === ward.requiredSkills.length && ward.requiredSkills.length > 0 }
      })
      .sort((a, b) => b.met.length - a.met.length)
  }, [wardId, wards, nurses])

  return (
    <>
      <PageHeader title="Skill Match" description="Match nurse competencies to ward requirements." />

      <Card>
        <CardHeader title="Match nurses to a ward" />
        <CardBody className="space-y-4">
          <label className="flex max-w-sm flex-col gap-1.5 text-sm">
            <span className="font-medium">Ward</span>
            <Select value={wardId} onChange={(e) => setWardId(e.target.value)}>
              <option value="all">Select a ward to see qualified nurses</option>
              {wards.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </Select>
          </label>

          {matches ? (
            matches.length === 0 ? (
              <EmptyState message="No nurses found." />
            ) : (
              <div className="grid gap-2 sm:grid-cols-2">
                {matches.map(({ nurse, met, full }) => (
                  <div key={nurse.id} className="flex items-center justify-between rounded-md border border-border p-3">
                    <div>
                      <p className="text-sm font-medium">{nurse.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {met.length ? met.join(", ") : "No matching skills"}
                      </p>
                    </div>
                    <Badge tone={full ? "success" : met.length ? "warning" : "danger"}>
                      {full ? "Fully qualified" : met.length ? "Partial" : "Not qualified"}
                    </Badge>
                  </div>
                ))}
              </div>
            )
          ) : null}
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Competency Matrix" description="Every nurse and the skills they hold." />
        <CardBody>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-muted-foreground">
                  <th className="sticky left-0 bg-card py-2 pr-4 font-medium">Nurse</th>
                  {ALL_SKILLS.map((s) => (
                    <th key={s} className="px-2 py-2 text-center text-xs font-medium">
                      {s}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {matrix.map(({ nurse, skills }) => (
                  <tr key={nurse.id} className="border-b border-border/60">
                    <td className="sticky left-0 bg-card py-2 pr-4 font-medium">{nurse.name}</td>
                    {ALL_SKILLS.map((s) => (
                      <td key={s} className="px-2 py-2 text-center">
                        {skills[s] ? (
                          <Check className="mx-auto size-4 text-emerald-600" />
                        ) : (
                          <X className="mx-auto size-4 text-border" />
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </>
  )
}
