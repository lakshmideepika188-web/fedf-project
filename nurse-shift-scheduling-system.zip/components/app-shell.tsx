"use client"

import { useState, type ReactNode } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  CalendarRange,
  CalendarPlus,
  ShieldCheck,
  Timer,
  PlaneTakeoff,
  TriangleAlert,
  Bell,
  UserRound,
  Settings,
  Activity,
  Menu,
  X,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useScheduling } from "@/lib/scheduling-context"

const NAV = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/roster", label: "Roster Builder", icon: CalendarRange },
  { href: "/shifts", label: "Shift Assignment", icon: CalendarPlus },
  { href: "/skills", label: "Skill Match", icon: ShieldCheck },
  { href: "/overtime", label: "Overtime Tracker", icon: Timer },
  { href: "/leave", label: "Leave Requests", icon: PlaneTakeoff },
  { href: "/conflicts", label: "Conflict Alerts", icon: TriangleAlert },
  { href: "/notifications", label: "Notifications", icon: Bell },
  { href: "/profile", label: "Profile", icon: UserRound },
  { href: "/admin", label: "Admin Panel", icon: Settings },
]

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const { conflicts, notifications } = useScheduling()
  const unread = notifications.filter((n) => !n.read).length

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-sidebar text-sidebar-foreground transition-transform lg:static lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center gap-2.5 border-b border-sidebar-border px-5 py-4">
          <span className="flex size-9 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
            <Activity className="size-5" aria-hidden="true" />
          </span>
          <div className="leading-tight">
            <p className="text-sm font-semibold">NurseShift</p>
            <p className="text-xs text-sidebar-foreground/60">Scheduling System</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = pathname === href
            const badge =
              href === "/conflicts" ? conflicts.length : href === "/notifications" ? unread : 0
            return (
              <Link
                key={href}
                href={href}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center justify-between rounded-md px-3 py-2 text-sm font-medium transition",
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <span className="flex items-center gap-3">
                  <Icon className="size-4" aria-hidden="true" />
                  {label}
                </span>
                {badge > 0 ? (
                  <span className="flex min-w-5 items-center justify-center rounded-full bg-red-500 px-1.5 text-xs font-semibold text-white">
                    {badge}
                  </span>
                ) : null}
              </Link>
            )
          })}
        </nav>

        <div className="border-t border-sidebar-border px-5 py-4 text-xs text-sidebar-foreground/60">
          Local demo · data saved in your browser
        </div>
      </aside>

      {/* Overlay for mobile */}
      {open ? (
        <div
          className="fixed inset-0 z-30 bg-black/40 lg:hidden"
          onClick={() => setOpen(false)}
          aria-hidden="true"
        />
      ) : null}

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-border bg-card/80 px-4 py-3 backdrop-blur lg:px-8">
          <button
            type="button"
            className="rounded-md p-2 text-foreground hover:bg-secondary lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle navigation"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
          <p className="text-sm text-muted-foreground">
            {new Date().toLocaleDateString(undefined, {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
          <Link
            href="/notifications"
            className="relative rounded-md p-2 text-foreground hover:bg-secondary"
            aria-label="Notifications"
          >
            <Bell className="size-5" />
            {unread > 0 ? (
              <span className="absolute right-1 top-1 size-2 rounded-full bg-red-500" />
            ) : null}
          </Link>
        </header>

        <main className="mx-auto w-full max-w-6xl flex-1 space-y-6 p-4 lg:p-8">{children}</main>
      </div>
    </div>
  )
}
