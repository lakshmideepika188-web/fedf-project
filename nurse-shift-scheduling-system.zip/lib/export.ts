import type { Assignment, Nurse, Ward } from "./types"

function escapeCsv(value: string): string {
  if (value.includes(",") || value.includes('"') || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`
  }
  return value
}

export function buildScheduleCsv(
  assignments: Assignment[],
  nurses: Nurse[],
  wards: Ward[],
): string {
  const header = ["Date", "Shift", "Ward", "Nurse", "Role", "Hours"]
  const rows = [...assignments]
    .sort((a, b) => (a.date === b.date ? a.shift.localeCompare(b.shift) : a.date.localeCompare(b.date)))
    .map((a) => {
      const nurse = nurses.find((n) => n.id === a.nurseId)
      const ward = wards.find((w) => w.id === a.wardId)
      return [
        a.date,
        a.shift,
        ward?.name ?? "Unknown",
        nurse?.name ?? "Unknown",
        nurse?.role ?? "",
        String(a.hours),
      ].map(escapeCsv)
    })
  return [header.join(","), ...rows.map((r) => r.join(","))].join("\n")
}

export function downloadCsv(filename: string, csv: string): void {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}
