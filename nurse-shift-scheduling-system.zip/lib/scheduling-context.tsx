"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react"
import type {
  AppNotification,
  Assignment,
  Conflict,
  LeaveRequest,
  Nurse,
  Ward,
} from "./types"
import { SHIFT_DEFS } from "./types"
import { SEED_ASSIGNMENTS, SEED_LEAVE, SEED_NURSES, SEED_WARDS } from "./seed-data"

const STORAGE_KEY = "nss-data-v1"

interface PersistedState {
  nurses: Nurse[]
  wards: Ward[]
  assignments: Assignment[]
  leave: LeaveRequest[]
  notifications: AppNotification[]
}

interface SchedulingContextValue extends PersistedState {
  conflicts: Conflict[]
  // nurse
  addNurse: (n: Omit<Nurse, "id">) => void
  updateNurse: (id: string, patch: Partial<Nurse>) => void
  removeNurse: (id: string) => void
  // ward
  addWard: (w: Omit<Ward, "id">) => void
  removeWard: (id: string) => void
  // assignment
  addAssignment: (a: Omit<Assignment, "id" | "hours">) => void
  removeAssignment: (id: string) => void
  // leave
  addLeave: (l: Omit<LeaveRequest, "id" | "status" | "createdAt">) => void
  setLeaveStatus: (id: string, status: LeaveRequest["status"]) => void
  removeLeave: (id: string) => void
  // notifications
  markNotificationRead: (id: string) => void
  markAllNotificationsRead: () => void
  clearNotifications: () => void
  // helpers
  weeklyHours: (nurseId: string) => number
  resetData: () => void
}

const SchedulingContext = createContext<SchedulingContextValue | null>(null)

function uid(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`
}

function rangesOverlap(aStart: string, aEnd: string, bStart: string, bEnd: string): boolean {
  return aStart <= bEnd && bStart <= aEnd
}

function defaultState(): PersistedState {
  return {
    nurses: SEED_NURSES,
    wards: SEED_WARDS,
    assignments: SEED_ASSIGNMENTS,
    leave: SEED_LEAVE,
    notifications: [
      {
        id: uid("ntf"),
        title: "Welcome to the scheduler",
        message: "Demo data has been loaded. Explore the modules from the sidebar.",
        level: "info",
        read: false,
        createdAt: new Date().toISOString(),
      },
    ],
  }
}

export function SchedulingProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(defaultState)
  const [hydrated, setHydrated] = useState(false)

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as PersistedState
        setState(parsed)
      }
    } catch (err) {
      console.log("[v0] Failed to load scheduling data:", (err as Error).message)
    }
    setHydrated(true)
  }, [])

  // Persist on change
  useEffect(() => {
    if (!hydrated) return
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch (err) {
      console.log("[v0] Failed to save scheduling data:", (err as Error).message)
    }
  }, [state, hydrated])

  const pushNotification = useCallback(
    (n: Omit<AppNotification, "id" | "read" | "createdAt">) => {
      setState((s) => ({
        ...s,
        notifications: [
          { ...n, id: uid("ntf"), read: false, createdAt: new Date().toISOString() },
          ...s.notifications,
        ],
      }))
    },
    [],
  )

  // ---- Weekly hours helper ----
  const weeklyHours = useCallback(
    (nurseId: string): number => {
      // sum hours within the current ISO week (Mon-Sun) of each assignment date
      const byWeek = new Map<string, number>()
      state.assignments
        .filter((a) => a.nurseId === nurseId)
        .forEach((a) => {
          const d = new Date(a.date)
          const day = (d.getDay() + 6) % 7 // monday = 0
          const monday = new Date(d)
          monday.setDate(d.getDate() - day)
          const key = monday.toISOString().slice(0, 10)
          byWeek.set(key, (byWeek.get(key) ?? 0) + a.hours)
        })
      // return the max weekly total (worst-case for overtime detection)
      let max = 0
      byWeek.forEach((v) => {
        if (v > max) max = v
      })
      return max
    },
    [state.assignments],
  )

  // ---- Conflict detection (derived) ----
  const conflicts = useMemo<Conflict[]>(() => {
    const result: Conflict[] = []
    const { assignments, nurses, wards, leave } = state

    // 1. Double booking — same nurse, same date, same shift OR overlapping shifts on same date
    const byNurseDate = new Map<string, Assignment[]>()
    assignments.forEach((a) => {
      const key = `${a.nurseId}|${a.date}`
      byNurseDate.set(key, [...(byNurseDate.get(key) ?? []), a])
    })
    byNurseDate.forEach((list) => {
      if (list.length > 1) {
        const shifts = new Set(list.map((a) => a.shift))
        // Any duplicate shift, or more than one shift on the same day, is a clash
        const nurse = nurses.find((n) => n.id === list[0].nurseId)
        if (shifts.size < list.length || list.length > 1) {
          result.push({
            id: `dbl_${list[0].nurseId}_${list[0].date}`,
            type: "Double Booking",
            nurseId: list[0].nurseId,
            message: `${nurse?.name ?? "Nurse"} has ${list.length} shifts on ${list[0].date}.`,
            assignmentIds: list.map((a) => a.id),
          })
        }
      }
    })

    // 2. On leave — assignment date falls within an approved leave window
    const approvedLeave = leave.filter((l) => l.status === "Approved")
    assignments.forEach((a) => {
      const onLeave = approvedLeave.find(
        (l) => l.nurseId === a.nurseId && a.date >= l.startDate && a.date <= l.endDate,
      )
      if (onLeave) {
        const nurse = nurses.find((n) => n.id === a.nurseId)
        result.push({
          id: `leave_${a.id}`,
          type: "On Leave",
          nurseId: a.nurseId,
          message: `${nurse?.name ?? "Nurse"} is scheduled on ${a.date} but is on approved ${onLeave.type} leave.`,
          assignmentIds: [a.id],
        })
      }
    })

    // 3. Skill mismatch — ward requires skills the nurse lacks
    assignments.forEach((a) => {
      const nurse = nurses.find((n) => n.id === a.nurseId)
      const ward = wards.find((w) => w.id === a.wardId)
      if (!nurse || !ward) return
      const missing = ward.requiredSkills.filter((s) => !nurse.skills.includes(s))
      if (missing.length === ward.requiredSkills.length && ward.requiredSkills.length > 0) {
        result.push({
          id: `skill_${a.id}`,
          type: "Skill Mismatch",
          nurseId: a.nurseId,
          message: `${nurse.name} lacks required skills for ${ward.name} (${ward.requiredSkills.join(", ")}).`,
          assignmentIds: [a.id],
        })
      }
    })

    // 4. Overtime — weekly hours exceed the nurse's max
    nurses.forEach((nurse) => {
      const byWeek = new Map<string, number>()
      assignments
        .filter((a) => a.nurseId === nurse.id)
        .forEach((a) => {
          const d = new Date(a.date)
          const day = (d.getDay() + 6) % 7
          const monday = new Date(d)
          monday.setDate(d.getDate() - day)
          const key = monday.toISOString().slice(0, 10)
          byWeek.set(key, (byWeek.get(key) ?? 0) + a.hours)
        })
      byWeek.forEach((hours, week) => {
        if (hours > nurse.maxHoursPerWeek) {
          result.push({
            id: `ot_${nurse.id}_${week}`,
            type: "Overtime",
            nurseId: nurse.id,
            message: `${nurse.name} is scheduled ${hours}h (limit ${nurse.maxHoursPerWeek}h) for week of ${week}.`,
            assignmentIds: assignments
              .filter((a) => a.nurseId === nurse.id)
              .map((a) => a.id),
          })
        }
      })
    })

    return result
  }, [state])

  // unused but referenced for overlap usage to avoid dead import
  void rangesOverlap

  // ---- Nurse CRUD ----
  const addNurse = useCallback(
    (n: Omit<Nurse, "id">) => {
      setState((s) => ({ ...s, nurses: [...s.nurses, { ...n, id: uid("n") }] }))
      pushNotification({
        title: "Nurse added",
        message: `${n.name} was added to the roster.`,
        level: "success",
      })
    },
    [pushNotification],
  )

  const updateNurse = useCallback((id: string, patch: Partial<Nurse>) => {
    setState((s) => ({
      ...s,
      nurses: s.nurses.map((n) => (n.id === id ? { ...n, ...patch } : n)),
    }))
  }, [])

  const removeNurse = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      nurses: s.nurses.filter((n) => n.id !== id),
      assignments: s.assignments.filter((a) => a.nurseId !== id),
      leave: s.leave.filter((l) => l.nurseId !== id),
    }))
  }, [])

  // ---- Ward CRUD ----
  const addWard = useCallback((w: Omit<Ward, "id">) => {
    setState((s) => ({ ...s, wards: [...s.wards, { ...w, id: uid("w") }] }))
  }, [])

  const removeWard = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      wards: s.wards.filter((w) => w.id !== id),
      assignments: s.assignments.filter((a) => a.wardId !== id),
    }))
  }, [])

  // ---- Assignment CRUD ----
  const addAssignment = useCallback(
    (a: Omit<Assignment, "id" | "hours">) => {
      const hours = SHIFT_DEFS[a.shift].hours
      setState((s) => ({
        ...s,
        assignments: [...s.assignments, { ...a, hours, id: uid("a") }],
      }))
    },
    [],
  )

  const removeAssignment = useCallback((id: string) => {
    setState((s) => ({ ...s, assignments: s.assignments.filter((a) => a.id !== id) }))
  }, [])

  // ---- Leave ----
  const addLeave = useCallback(
    (l: Omit<LeaveRequest, "id" | "status" | "createdAt">) => {
      setState((s) => ({
        ...s,
        leave: [
          {
            ...l,
            id: uid("l"),
            status: "Pending",
            createdAt: new Date().toISOString(),
          },
          ...s.leave,
        ],
      }))
      pushNotification({
        title: "Leave request submitted",
        message: `A ${l.type} leave request is awaiting review.`,
        level: "info",
      })
    },
    [pushNotification],
  )

  const setLeaveStatus = useCallback(
    (id: string, status: LeaveRequest["status"]) => {
      setState((s) => ({
        ...s,
        leave: s.leave.map((l) => (l.id === id ? { ...l, status } : l)),
      }))
      pushNotification({
        title: `Leave ${status.toLowerCase()}`,
        message: `A leave request has been ${status.toLowerCase()}.`,
        level: status === "Approved" ? "success" : status === "Rejected" ? "danger" : "info",
      })
    },
    [pushNotification],
  )

  const removeLeave = useCallback((id: string) => {
    setState((s) => ({ ...s, leave: s.leave.filter((l) => l.id !== id) }))
  }, [])

  // ---- Notifications ----
  const markNotificationRead = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      notifications: s.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
    }))
  }, [])

  const markAllNotificationsRead = useCallback(() => {
    setState((s) => ({
      ...s,
      notifications: s.notifications.map((n) => ({ ...n, read: true })),
    }))
  }, [])

  const clearNotifications = useCallback(() => {
    setState((s) => ({ ...s, notifications: [] }))
  }, [])

  const resetData = useCallback(() => {
    setState(defaultState())
  }, [])

  const value: SchedulingContextValue = {
    ...state,
    conflicts,
    addNurse,
    updateNurse,
    removeNurse,
    addWard,
    removeWard,
    addAssignment,
    removeAssignment,
    addLeave,
    setLeaveStatus,
    removeLeave,
    markNotificationRead,
    markAllNotificationsRead,
    clearNotifications,
    weeklyHours,
    resetData,
  }

  return <SchedulingContext.Provider value={value}>{children}</SchedulingContext.Provider>
}

export function useScheduling(): SchedulingContextValue {
  const ctx = useContext(SchedulingContext)
  if (!ctx) throw new Error("useScheduling must be used within a SchedulingProvider")
  return ctx
}
