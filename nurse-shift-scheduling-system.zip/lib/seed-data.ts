import type { Assignment, LeaveRequest, Nurse, Ward } from "./types"

// Helper to build dates relative to today (so the demo always looks current)
function dayOffset(offset: number): string {
  const d = new Date()
  d.setDate(d.getDate() + offset)
  return d.toISOString().slice(0, 10)
}

export const SEED_WARDS: Ward[] = [
  { id: "w1", name: "Intensive Care Unit", requiredSkills: ["ICU", "Cardiology"], minStaffPerShift: 3 },
  { id: "w2", name: "Emergency Department", requiredSkills: ["Emergency", "Triage"], minStaffPerShift: 4 },
  { id: "w3", name: "Pediatrics Ward", requiredSkills: ["Pediatrics"], minStaffPerShift: 2 },
  { id: "w4", name: "Surgical Ward", requiredSkills: ["Surgery", "Wound Care"], minStaffPerShift: 3 },
  { id: "w5", name: "Maternity Ward", requiredSkills: ["Maternity"], minStaffPerShift: 2 },
  { id: "w6", name: "Oncology Ward", requiredSkills: ["Oncology"], minStaffPerShift: 2 },
]

export const SEED_NURSES: Nurse[] = [
  {
    id: "n1",
    name: "Sarah Mitchell",
    email: "sarah.mitchell@hospital.org",
    phone: "+1 (555) 201-3344",
    role: "Charge Nurse",
    skills: ["ICU", "Cardiology", "Emergency"],
    preferredWardId: "w1",
    maxHoursPerWeek: 40,
    active: true,
  },
  {
    id: "n2",
    name: "James Carter",
    email: "james.carter@hospital.org",
    phone: "+1 (555) 201-7788",
    role: "Registered Nurse",
    skills: ["Emergency", "Triage", "Wound Care"],
    preferredWardId: "w2",
    maxHoursPerWeek: 36,
    active: true,
  },
  {
    id: "n3",
    name: "Emily Nguyen",
    email: "emily.nguyen@hospital.org",
    phone: "+1 (555) 202-1199",
    role: "Registered Nurse",
    skills: ["Pediatrics", "Maternity"],
    preferredWardId: "w3",
    maxHoursPerWeek: 40,
    active: true,
  },
  {
    id: "n4",
    name: "Michael Brooks",
    email: "michael.brooks@hospital.org",
    phone: "+1 (555) 203-4455",
    role: "Licensed Practical Nurse",
    skills: ["Surgery", "Wound Care"],
    preferredWardId: "w4",
    maxHoursPerWeek: 32,
    active: true,
  },
  {
    id: "n5",
    name: "Olivia Davis",
    email: "olivia.davis@hospital.org",
    phone: "+1 (555) 204-6677",
    role: "Registered Nurse",
    skills: ["Oncology", "Geriatrics"],
    preferredWardId: "w6",
    maxHoursPerWeek: 40,
    active: true,
  },
  {
    id: "n6",
    name: "Daniel Lopez",
    email: "daniel.lopez@hospital.org",
    phone: "+1 (555) 205-8822",
    role: "Nursing Assistant",
    skills: ["Geriatrics", "Wound Care"],
    preferredWardId: "w4",
    maxHoursPerWeek: 36,
    active: true,
  },
  {
    id: "n7",
    name: "Sophia Patel",
    email: "sophia.patel@hospital.org",
    phone: "+1 (555) 206-3300",
    role: "Registered Nurse",
    skills: ["ICU", "Cardiology"],
    preferredWardId: "w1",
    maxHoursPerWeek: 40,
    active: true,
  },
  {
    id: "n8",
    name: "William Turner",
    email: "william.turner@hospital.org",
    phone: "+1 (555) 207-9911",
    role: "Licensed Practical Nurse",
    skills: ["Maternity", "Pediatrics"],
    preferredWardId: "w5",
    maxHoursPerWeek: 32,
    active: false,
  },
]

export const SEED_ASSIGNMENTS: Assignment[] = [
  { id: "a1", nurseId: "n1", wardId: "w1", date: dayOffset(0), shift: "Morning", hours: 8 },
  { id: "a2", nurseId: "n7", wardId: "w1", date: dayOffset(0), shift: "Morning", hours: 8 },
  { id: "a3", nurseId: "n2", wardId: "w2", date: dayOffset(0), shift: "Evening", hours: 8 },
  { id: "a4", nurseId: "n3", wardId: "w3", date: dayOffset(1), shift: "Morning", hours: 8 },
  // Intentional skill mismatch (Daniel has no Oncology) to demo conflict alerts
  { id: "a5", nurseId: "n6", wardId: "w6", date: dayOffset(1), shift: "Night", hours: 8 },
  { id: "a6", nurseId: "n1", wardId: "w1", date: dayOffset(2), shift: "Morning", hours: 8 },
  { id: "a7", nurseId: "n1", wardId: "w2", date: dayOffset(2), shift: "Morning", hours: 8 },
]

export const SEED_LEAVE: LeaveRequest[] = [
  {
    id: "l1",
    nurseId: "n5",
    type: "Annual",
    startDate: dayOffset(3),
    endDate: dayOffset(7),
    reason: "Family vacation",
    status: "Pending",
    createdAt: dayOffset(-2),
  },
  {
    id: "l2",
    nurseId: "n4",
    type: "Sick",
    startDate: dayOffset(0),
    endDate: dayOffset(1),
    reason: "Flu symptoms",
    status: "Approved",
    createdAt: dayOffset(-1),
  },
]
