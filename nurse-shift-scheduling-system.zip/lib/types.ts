// Core domain types for the Nurse Shift Scheduling System

export type Role = "Charge Nurse" | "Registered Nurse" | "Licensed Practical Nurse" | "Nursing Assistant"

export type ShiftType = "Morning" | "Evening" | "Night"

export type Skill =
  | "ICU"
  | "Pediatrics"
  | "Emergency"
  | "Surgery"
  | "Cardiology"
  | "Oncology"
  | "Geriatrics"
  | "Maternity"
  | "Triage"
  | "Wound Care"

export type LeaveType = "Annual" | "Sick" | "Personal" | "Maternity" | "Bereavement"

export type LeaveStatus = "Pending" | "Approved" | "Rejected"

export interface Nurse {
  id: string
  name: string
  email: string
  phone: string
  role: Role
  skills: Skill[]
  preferredWardId: string | null
  maxHoursPerWeek: number
  active: boolean
}

export interface Ward {
  id: string
  name: string
  requiredSkills: Skill[]
  minStaffPerShift: number
}

export interface Assignment {
  id: string
  nurseId: string
  wardId: string
  // ISO date string (yyyy-mm-dd)
  date: string
  shift: ShiftType
  hours: number
}

export interface LeaveRequest {
  id: string
  nurseId: string
  type: LeaveType
  startDate: string
  endDate: string
  reason: string
  status: LeaveStatus
  createdAt: string
}

export interface AppNotification {
  id: string
  title: string
  message: string
  level: "info" | "warning" | "danger" | "success"
  read: boolean
  createdAt: string
}

export type ConflictType = "Double Booking" | "On Leave" | "Skill Mismatch" | "Overtime"

export interface Conflict {
  id: string
  type: ConflictType
  nurseId: string
  message: string
  // related assignment ids
  assignmentIds: string[]
}

// Shift definitions: start/end hours used to compute duration & overlap
export const SHIFT_DEFS: Record<ShiftType, { label: string; start: string; end: string; hours: number }> = {
  Morning: { label: "Morning (07:00 - 15:00)", start: "07:00", end: "15:00", hours: 8 },
  Evening: { label: "Evening (15:00 - 23:00)", start: "15:00", end: "23:00", hours: 8 },
  Night: { label: "Night (23:00 - 07:00)", start: "23:00", end: "07:00", hours: 8 },
}

export const ALL_SKILLS: Skill[] = [
  "ICU",
  "Pediatrics",
  "Emergency",
  "Surgery",
  "Cardiology",
  "Oncology",
  "Geriatrics",
  "Maternity",
  "Triage",
  "Wound Care",
]

export const ALL_ROLES: Role[] = [
  "Charge Nurse",
  "Registered Nurse",
  "Licensed Practical Nurse",
  "Nursing Assistant",
]

export const ALL_SHIFTS: ShiftType[] = ["Morning", "Evening", "Night"]

export const ALL_LEAVE_TYPES: LeaveType[] = ["Annual", "Sick", "Personal", "Maternity", "Bereavement"]
